NABZ v1.13 source pack
Read first: src/lib/engine.ts, src/lib/risk.ts, src/lib/server/lock.ts,
src/lib/server/market.ts, src/lib/server/toobit.ts, src/lib/server/desk-chat.ts,
src/routes/journal.tsx, src/routes/chat.tsx, src/lib/store.ts, src/lib/types.ts
